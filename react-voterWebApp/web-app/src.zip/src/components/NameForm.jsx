import { useState } from 'react'
import { authenticateNamedUser } from '../api/auth'

export default function NameForm({ onAuth }) {
  const [name, setName] = useState('')

  const handleSubmit = async (e) => {
    e.preventDefault()
    console.log("Name entered:", name) 
    // const { token } = await authenticateNamedUser(name)
    // sessionStorage.setItem('accessToken', token)
    // onAuth(token)
  }

  return (
    <form onSubmit={handleSubmit}>
      <label>Enter your name:</label>
      <input
        type="text"
        value={name}
        onChange={(e) => setName(e.target.value)}
        required
      />
      <button type="submit">Start Poll</button>
    </form>
  )
}
