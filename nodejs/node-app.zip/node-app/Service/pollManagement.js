const { v4: uuidv4 } = require('uuid')
const pool = require('../db/dbService')

async function createPoll(title, questions) {
  const client = await pool.connect()
  try {
    await client.query('BEGIN')
    const pollId = uuidv4()
    await client.query(
      'INSERT INTO polls (id,title,status) VALUES ($1,$2,$3)',
      [pollId, title, 'active']
    )
    for (let i = 0; i < questions.length; i++) {
      const qId = uuidv4()
      await client.query(
        'INSERT INTO questions (id,poll_id,text,"order") VALUES ($1,$2,$3,$4)',
        [qId, pollId, questions[i].text, i + 1]
      )
      for (const opt of questions[i].options) {
        await client.query(
          'INSERT INTO options (id,question_id,text) VALUES ($1,$2,$3)',
          [uuidv4(), qId, opt]
        )
      }
    }
    await client.query('COMMIT')
    return pollId
  } catch (e) {
    await client.query('ROLLBACK')
    throw e
  } finally {
    client.release()
  }
}

async function setStatus(pollId, status) {
  await pool.query('UPDATE polls SET status=$1 WHERE id=$2', [status, pollId])
}

async function deletePoll(pollId) {
  await pool.query('DELETE FROM polls WHERE id=$1', [pollId])
}

async function getActivePolls() {
  const { rows } = await pool.query(
    'SELECT id,title FROM polls WHERE status=$1 ORDER BY created_at DESC',
    ['active']
  )
  return rows
}

module.exports = { createPoll, setStatus, deletePoll, getActivePolls }
