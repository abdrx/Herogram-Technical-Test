
const pool = require('./dbService')

async function tableExists(tableName) {
  const res = await pool.query(
    `SELECT EXISTS (
       SELECT FROM information_schema.tables 
       WHERE table_schema = 'public' AND table_name = $1
     )`, [tableName]
  )
  return res.rows[0].exists
}

async function createSchema() {
  const queries = []

  if (!(await tableExists('polls'))) {
    queries.push(`
      CREATE TABLE polls (
        id UUID PRIMARY KEY,
        title TEXT NOT NULL,
        status TEXT CHECK (status IN ('active', 'closed')) NOT NULL DEFAULT 'active',
        created_at TIMESTAMP DEFAULT NOW()
      );
    `)
  }

  if (!(await tableExists('questions'))) {
    queries.push(`
      CREATE TABLE questions (
        id UUID PRIMARY KEY,
        poll_id UUID REFERENCES polls(id),
        text TEXT NOT NULL,
        "order" INT
      );
    `)
  }

  if (!(await tableExists('options'))) {
    queries.push(`
      CREATE TABLE options (
        id UUID PRIMARY KEY,
        question_id UUID REFERENCES questions(id),
        text TEXT NOT NULL
      );
    `)
  }

  for (const q of queries) {
    await pool.query(q)
  }

  console.log('Tables checked and created if needed.')
}

module.exports = { createSchema }
