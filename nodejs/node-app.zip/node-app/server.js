
const { createSchema } = require('./db/schemaManager')

const fastify = require('fastify')({ logger: true })
fastify.register(require('@fastify/cors'), {
  origin: ['http://localhost:5173', 'http://localhost:5174']  // dev ports
})
