import React from 'react'

export default function Dashboard () {
  return (
    <section>
      <h3>Dashboard</h3>
      <p>(widgets coming soon…)</p>
    </section>
  )
}
