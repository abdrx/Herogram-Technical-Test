import React from 'react'

export default function Topbar () {
  return (
    <header className="topbar">
      <span>Team Polls Admin</span>
    </header>
  )
}
